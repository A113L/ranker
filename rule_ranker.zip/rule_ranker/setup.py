#!/usr/bin/env python3
from setuptools import setup, find_packages

setup(
    name="rule_ranker",
    version="1.0.0",
    description="GPU-accelerated Hashcat rule ranking, analysis, and CELF coverage post-processing",
    packages=find_packages(include=["rule_ranker", "rule_ranker.*"]),
    py_modules=["run_ranker"],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21",
        "tqdm>=4.60",
        "pyopencl>=2022.1",
    ],
    extras_require={
        "gpu-celf": ["cupy-cuda12x>=12.0"],
        "test": ["pytest>=7.0"],
    },
    entry_points={
        "console_scripts": [
            "run-ranker=run_ranker:main",
        ],
    },
)
